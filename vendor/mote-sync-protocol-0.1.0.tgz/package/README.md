# mote-sync-protocol

mote 同步的协议包：协议类型、三方合并和这份协议说明。Mac 端和同步服务都依赖这个包。iOS 端用 Swift 照这份说明实现。

类型以 `src/protocol.ts` 为准。这里写语义，字段名和它一致。术语见 mote-mac 的 `CONTEXT.md` 的"同步"一节。

> **实现状态**：下表的 v1 接口（含注册、登录、改密码、登出）都已在 `mote-sync-server` 0.1.0 实现。

## 基本约定

- 协议版本写在路径里：`/v1/`。不兼容的改动才换 `/v2/`。
- 传输用 HTTPS。同步服务用自签证书，设备做证书固定：只接受指纹和设置里一致的证书。指纹是证书 DER 字节的 SHA-256。`mote-sync cert fingerprint` 打印的格式是大写十六进制、冒号分隔，和 `openssl x509 -noout -fingerprint -sha256` 一样。
- 请求体和回应体是 UTF-8 的 JSON，`Content-Type: application/json`。内容（blob）的上传和下载例外，是原始字节。
- JSON 请求体最多 64 KiB。超过：413 `too_large`。
- 读 JSON 时忽略不认识的字段。服务端以后可以加字段，旧客户端照常工作。
- 协议只做加法，见 mote-mac 的 ADR 0023。

## 账户

- 一个账户有自己的用户名、密码、找回码、笔记库和设备。笔记库和存储上限按账户算。
- 注册是公开的。注册成功时服务端一次建好账户、一个笔记库和一台设备。
- 用户名 3 到 32 个字符，只用字母、数字、`_`、`-`。不分大小写，服务端存小写。
- 密码 8 到 200 个字符。服务端用 scrypt 加盐存哈希，不存明文。
- 每个账户最多 10 台设备。
- 找回码在注册和每次改密码时给一次。服务端只存它的哈希。用户丢了密码和找回码，没有邮箱可找回，见 mote-mac 的 ADR 0029。

## 鉴权

- 不用令牌的接口只有四个：`GET /v1/health`、`POST /v1/register`、`POST /v1/login`、`POST /v1/password`。
- 其他每个请求都带设备令牌：`Authorization: Bearer <设备令牌>`。
- 令牌来自注册、登录，或服务器命令行 `device create`。
- 服务端按令牌找到账户和设备。令牌缺失、错误或设备已撤销：401 `unauthorized`。
- 路径里带笔记库编号 `:id`。服务端检查它属于这个账户。不属于或不存在：403 `forbidden`。两种情况回应一样，不泄露别的账户有哪些笔记库。
- 客户端把令牌存进系统钥匙串，不写进笔记库。

## 数据类型

| 类型          | JSON   | 规则                                                                                              |
| ------------- | ------ | ------------------------------------------------------------------------------------------------- |
| `VaultId`     | string | 笔记库编号。1 到 64 个字符，只用 `A-Z a-z 0-9 _ -`                                                |
| `VaultPath`   | string | 笔记库里的相对路径，见下                                                                          |
| `ContentHash` | string | 文件字节的 SHA-256，64 个小写十六进制字符                                                         |
| `Seq`         | number | 版本号。非负整数，不超过 2^53 − 1。每个笔记库一个序列，从 0 开始。服务端每接受一次改动，版本号加 1 |

`VaultPath` 的规则：

- 用 `/` 分隔，不以 `/` 开头，不以 `/` 结尾。
- 每一段都不为空，不以 `.` 开头。所以 `.`、`..`、`.obsidian/x`、`a/.DS_Store` 都不合法。
- 例外是 mote 的附件文件夹：`.mote/attachments/` 下面的路径合法，例如 `.mote/attachments/图.png`。`.mote/attachments/` 本身是目录，不合法；它下面也不能再有以 `.` 开头的段。
- 不含反斜杠 `\`、NUL 和不成对的 UTF-16 代理项。
- UTF-8 编码后不超过 1024 字节。
- 其他以 `.` 开头的目录不参与同步，客户端不提交里面的文件。

### 文件的状态 `Change`

```json
{ "path": "日记/2026-11-23.md", "hash": "<ContentHash>", "seq": 12, "size": 2048, "deleted": false }
{ "path": "旧笔记.md", "hash": null, "seq": 13, "size": 0, "deleted": true }
```

- `seq` 是这个文件最后一次被改动时笔记库的版本号。
- `size` 是内容的字节数。
- 删除的文件 `deleted` 为 `true`，`hash` 为 `null`，`size` 为 `0`。服务端不真删，内容留作历史版本。

## 接口

| 方法 | 路径                          | 用途                       | v1 已实现 |
| ---- | ----------------------------- | -------------------------- | --------- |
| GET  | `/v1/health`                  | 检查服务是否在线，不要令牌 | 是        |
| POST | `/v1/register`                | 注册账户，不要令牌         | 是        |
| POST | `/v1/login`                   | 登录，拿新设备令牌，不要令牌 | 是      |
| POST | `/v1/password`                | 用找回码改密码，不要令牌   | 是        |
| POST | `/v1/logout`                  | 撤销当前设备               | 是        |
| GET  | `/v1/vaults`                  | 列出账户下的笔记库         | 是        |
| GET  | `/v1/vaults/:id/changes`      | 拉取某个版本号之后的改动   | 是        |
| POST | `/v1/vaults/:id/changes`      | 提交一个文件的改动         | 是        |
| HEAD | `/v1/vaults/:id/blobs/:hash`  | 问服务端有没有这份内容     | 是        |
| PUT  | `/v1/vaults/:id/blobs/:hash`  | 上传内容                   | 是        |
| GET  | `/v1/vaults/:id/blobs/:hash`  | 下载内容                   | 是        |
| GET  | `/v1/ws`                      | WebSocket，接收改动通知    | 是        |

### GET /v1/health

不要令牌。回应 200：

```json
{ "ok": true, "version": "0.1.0" }
```

`version` 是同步服务的版本，不是协议版本。

### POST /v1/register

请求体 `RegisterRequest`：

```json
{ "username": "wenli", "password": "correct horse" }
```

- 用户名已存在（不分大小写）：409 `conflict`。
- 同一次注册建好账户、一个笔记库（名字是 `vault`）和一台设备（名字是 `registration`）。
- 成功回应 **201**，`Registration`：

  ```json
  {
    "account": { "id": "…", "username": "wenli" },
    "token": "<设备令牌>",
    "recoveryCode": "<找回码>",
    "vaultId": "<笔记库编号>"
  }
  ```

- `recoveryCode` 只在这里给一次，客户端要让用户抄下来。
- 同一地址每小时最多 5 次：429 `too_many`。

### POST /v1/login

请求体 `LoginRequest`：

```json
{ "username": "wenli", "password": "correct horse", "deviceName": "MacBook Pro" }
```

- `deviceName` 可选，1 到 64 个字符，没给时是 `unknown`。它只出现在设备列表里。
- 每登录一次新建一台设备。之前登录拿到的令牌仍然有效。
- 成功回应 200，`LoginResponse`：

  ```json
  { "account": { "id": "…", "username": "wenli" }, "token": "<设备令牌>" }
  ```

- 账户没有笔记库时，登录顺手建一个。
- 用户名不存在和密码错误回应一样：401 `unauthorized`，`message` 都是 `wrong username or password`。这样不泄露用户名是否存在。
- 账户已有 10 台设备：409 `conflict`。先撤销不用的设备。
- 同一地址 1 小时内登录失败 20 次：429 `too_many`。成功一次就清零。

### POST /v1/password

用找回码改密码。请求体 `RecoverRequest`：

```json
{ "username": "wenli", "recoveryCode": "<找回码>", "password": "<新密码>" }
```

- 找回码不对：401 `unauthorized`，`message` 是 `wrong username or recovery code`。
- 成功回应 200，和注册一样带 `account`、`token`、`recoveryCode`、`vaultId`：
  - 账户下的所有旧设备令牌立刻失效。
  - 服务端换一个新找回码，旧码作废。回应里的 `recoveryCode` 是新码。
  - 回应里的 `token` 属于一台新设备，名字是 `password reset`。
- 同一地址每小时最多 10 次：429 `too_many`。

### POST /v1/logout

不带请求体，带设备令牌。服务端撤销这个令牌对应的设备，回应 **204**，没有回应体。之后这个令牌回应 401。同一账户的其他设备不受影响。

### GET /v1/vaults

回应 200，`VaultList`：

```json
{ "vaults": [{ "id": "life-os", "name": "life-os", "seq": 42 }] }
```

`seq` 是笔记库当前的版本号。客户端连上后先调它。只有一个笔记库时自动选中。

### GET /v1/vaults/:id/changes?since=<Seq>

拉取版本号大于 `since` 的所有文件。回应 200，`ChangesPage`：

```json
{ "changes": [<Change>, ...], "next": 42, "complete": true }
```

- `changes` 按 `seq` 从小到大排列。每个路径最多出现一次，给的是它的最新状态，包括删除。
- 每页多少条由服务端决定。
- 下一页用 `next` 当 `since` 再请求，直到 `complete` 为 `true`。
- `complete` 为 `true` 时，`next` 等于笔记库当前的版本号。客户端把它记进同步状态表。
- 第一次同步用 `since=0`。
- `since` 缺失或不是非负整数：400 `bad_request`。

### POST /v1/vaults/:id/changes

提交一个文件的改动。请求体是 `CommitItem`：

```json
{ "path": "a.md", "hash": "<ContentHash>", "baseSeq": 12, "deleted": false }
{ "path": "a.md", "hash": null, "baseSeq": 12, "deleted": true }
```

`baseSeq` 是客户端同步状态表里这个文件的版本号。客户端从没见过这个文件时填 `0`。

服务端用乐观并发：比较 `baseSeq` 和这个文件在服务端的最新版本号。文件从没存在过时，最新版本号算 `0`；已删除的文件也有版本号。

- 相等：接受。笔记库的版本号加 1，文件记为新的版本号。回应 200，`CommitResult`：

  ```json
  { "ok": true, "seq": 43 }
  ```

  服务端随后通过 WebSocket 通知账户下的其他设备。

- 不相等：拒绝，什么也不改。回应 **409**，回应体也是 `CommitResult`，带服务端的最新状态：

  ```json
  { "ok": false, "conflict": { "hash": "<ContentHash 或 null>", "seq": 41 } }
  ```

  `hash` 为 `null` 表示服务端上这个文件已删除或从没存在过。客户端拿到 409 后下载远程内容，走合并，再用 `conflict.seq` 当 `baseSeq` 重新提交。

- 重试：如果 409 里的 `hash` 等于客户端这次提交的 `hash`（删除时都是 `null`），说明上一次提交其实成功了，只是回应丢了。客户端按成功处理，用 `conflict.seq` 更新同步状态表。

其他错误：

- 请求体形状不对：400 `protocol`。路径、哈希或版本号不合规：400 `bad_request`。
- `deleted` 为 `false`，但这个笔记库不能引用这份内容（见 HEAD）：400 `bad_request`。客户端要先上传内容，再提交。

改名在协议里是一次删除加一次新建。新路径的哈希没变，不用重新上传内容。

### HEAD /v1/vaults/:id/blobs/:hash

问这个笔记库能不能直接引用这份内容。

- 200：能。不用上传，直接提交。
- 404：不能。先 PUT。

服务端只对这个笔记库引用过或上传过的内容回答 200。别的账户有同样的内容时也回答 404，这样 HEAD 不会泄露别的账户存了什么。

“上传过”只算 1 小时。上传后 1 小时内没有提交，清理任务可能删掉这份内容，HEAD 又回答 404，客户端重新上传即可。

### PUT /v1/vaults/:id/blobs/:hash

上传内容。请求体是文件的原始字节，`Content-Type: application/octet-stream`，必须带 `Content-Length`。

- 没有 `Content-Length`（例如分块传输）：400 `bad_request`。
- 服务端边收边算 SHA-256。结果和路径里的 `:hash` 不一致：400 `bad_request`，内容丢掉。
- 单个文件超过大小上限：413 `too_large`。
- 内容目录超过存储上限：507 `storage_full`。
- 成功：204，没有回应体。内容已经存在时也回答 204，所以重试是安全的。

### GET /v1/vaults/:id/blobs/:hash

下载内容。回应 200，原始字节，`Content-Type: application/octet-stream`，带 `Content-Length`。可见范围和 HEAD 一样，看不到时回应 404 `not_found`。

客户端合并时用它取同步基准：按同步状态表里的哈希请求。服务端按保留期保留历史版本的内容，过期后回应 404。

## WebSocket：GET /v1/ws

- 用同一个端口升级成 WebSocket。升级请求带 `Authorization: Bearer <设备令牌>`。令牌不对时，服务端不升级，回应 401。
- 服务端发文本帧，每帧一个 JSON 消息 `ServerMessage`。客户端不发 JSON 消息。
- 连上后，服务端先发 `hello`，列出账户下每个笔记库的当前版本号：

  ```json
  { "type": "hello", "vaults": [{ "id": "life-os", "seq": 42 }] }
  ```

- 一个笔记库接受了改动，服务端给账户下其他设备的连接发 `change`。提交它的那台设备不会收到。消息只带版本号，不带内容：

  ```json
  { "type": "change", "vault": "life-os", "seq": 43 }
  ```

- 客户端收到版本号大于本地记录的 `hello` 或 `change`，就调 `GET /v1/vaults/:id/changes` 拉取。版本号不大于本地记录时忽略，所以收到自己提交的通知也无害。
- 不认识的 `type` 直接忽略。
- 心跳用 WebSocket 的 ping 帧，不用 JSON。客户端每 30 秒发一次 ping。两次没收到 pong 就断开重连。
- 服务端也每 30 秒发一次 ping。上一次的 ping 没收到 pong，或者设备已被撤销，服务端就断开这条连接。
- 重连的等待从 1 秒开始，每次加倍，最长 60 秒。重连后先下载，再上传。

## 错误

除了提交冲突的 409，错误的回应体都是 `ErrorBody`：

```json
{ "error": { "code": "bad_request", "message": "invalid vault path" } }
```

`message` 只给人看和写日志，客户端不要按它分支。回应体读不出来，或 `code` 不认识时，按 HTTP 状态码处理。

| `code`         | HTTP | 含义                                                       |
| -------------- | ---- | ---------------------------------------------------------- |
| `protocol`     | 400  | 请求体形状不对：不是 JSON、缺字段、字段的 JSON 类型不对    |
| `bad_request`  | 400  | 形状对，值不合规：路径、哈希、版本号不合法，或内容哈希不符 |
| `unauthorized` | 401  | 没有设备令牌，令牌错误或已撤销                             |
| `forbidden`    | 403  | 笔记库不属于这个账户，或不存在                             |
| `not_found`    | 404  | 接口不存在，或请求的内容看不到                             |
| `conflict`     | 409  | 提交的 `baseSeq` 不是最新的，或用户名已占用、设备已满      |
| `too_many`     | 429  | 同一地址的尝试次数超过上限                                 |
| `too_large`    | 413  | 单个文件超过大小上限，或 JSON 请求体超过 64 KiB            |
| `storage_full` | 507  | 内容目录超过存储上限                                       |

## 上限和保留期

单元 B 定下的值。括号里是覆盖它的环境变量。

| 项目               | 值                                                                 |
| ------------------ | ------------------------------------------------------------------ |
| 单个文件           | 200 MiB（`MAX_FILE_BYTES`），超过回应 413                           |
| 内容目录总和       | 8 GiB（`MAX_STORE_BYTES`），超过回应 507                            |
| 笔记的历史版本     | 30 天。笔记指路径以 `.md` 结尾的文件                                |
| 附件的历史版本     | 14 天。附件指其他文件                                               |
| 没有引用的内容     | 上传或重新上传后保留 1 小时，之后清理                               |
| 每个账户的存储     | 1 GiB（`DEFAULT_QUOTA_BYTES`），超过回应 507                        |
| 每个账户的设备     | 10 台（`DEFAULT_MAX_DEVICES`），超过时登录回应 409                  |
| 注册 / 改密码      | 同一地址每小时 5 次 / 10 次                                         |
| 登录失败           | 同一地址每小时 20 次，成功一次清零                                  |

文件的当前状态不算历史版本，不管多旧都不清理。清理由 `mote-sync gc` 执行。

## 三方合并

`mergeText(base, local, remote)` 在 `src/merge.ts`。`base` 是同步基准，`local` 是本机内容，`remote` 是远程内容。iOS 端要实现同样的规则，两端合并出的结果才一致。

调用方负责规范化：合并前去掉 BOM，换行符统一成 `\n`；合并后还原本机文件的 BOM 和换行符。不是 UTF-8 文本的文件不合并，按冲突文件处理。

步骤：

1. `local` 等于 `remote`，或 `remote` 等于 `base`：返回 `local`。`local` 等于 `base`：返回 `remote`。
2. 拆行。空串是 0 行。否则按 `\n` 拆开；最后一段是空串时去掉它，记下"以换行结尾"。
3. 去掉三份共同的开头行和共同的结尾行。剩下的叫中间段。
4. 分别求"基准→本机"和"基准→远程"的最长公共子序列。先去掉两份共同的首尾行，余下的用 Myers 的贪心算法（1986 年论文 "An O(ND) Difference Algorithm"）向前搜索。第 d 步在对角线 k 上：`k == -d`，或 `k != d` 且 `V[k-1] < V[k+1]` 时，从 k+1 向下走，否则从 k-1 向右走。编辑次数超过 2000 时放弃，中间段输出本机的全部，再接远程的全部。
5. 沿基准逐行走。一行基准两边都保留，且两边在它前面都没有插入，就原样输出。两行这样的基准之间是一块：
   - 本机这块等于基准：用远程的。
   - 远程这块等于基准，或两边相同：用本机的。
   - 否则两边都改了：先本机，后远程。不加冲突标记。
6. 结尾换行：本机的和基准一样时用远程的，否则用本机的。合并结果是 0 行时返回空串。

比较行时按 UTF-16 码元逐个比较。Swift 的 `String ==` 按 Unicode 规范等价比较，结果会不一样，要比较 `utf16` 视图。

例子：

| 基准       | 本机       | 远程          | 结果              |
| ---------- | ---------- | ------------- | ----------------- |
| `a b c`    | `a X c`    | `a Y c`       | `a X Y c`         |
| `a b c d`  | `a d`      | `a b C d`     | `a b C d`（改赢删） |
| `a b`      | `a L b`    | `a b R`       | `a L b R`         |
| 空         | `x`        | `y`           | `x y`             |

表里一个字母是一行。

## 还没定的

| 问题                           | 现状                                                   |
| ------------------------------ | ------------------------------------------------------ |
| 路径的 Unicode 规范化（NFC）   | 协议按字节比较路径，不做规范化。iOS 接入前要定         |
| 路径的大小写                   | 按字节区分大小写                                       |
